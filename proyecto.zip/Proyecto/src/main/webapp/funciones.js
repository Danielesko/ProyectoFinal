/**
 * 
 */
$(document).ready(function() {
	$("#botonregistro").click(verificarRegistro);
	$("#botoninicio").click(verificarInicio);
	$("#botonaleatorio").click(aleatorio);
	//$("#mostrarguardados").click(mostrarguardados);
})
function validarcorreo(dato) {
	let verdadero = true;
	let ex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
	if (!ex.test(dato)) {
		verdadero = false;
	}
	return verdadero;
}
function validarcontra(dato) {
	let verdadero = true;
	let ex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
	if (!ex.test(dato)) {
		verdadero = false;
	}
	return verdadero;
}
function verificarInicio() {
	let correo1 = document.getElementById("correo").value;
	let contra1 = document.getElementById("contrasenaInicio").value;
	let correoIni = correo1.trim();
	let contraIni = contra1.trim();
	let errores = [];
	if (validarcorreo(correoIni) == false) {
		errores.push("El correo no esta en un formato correcto \n");
	}
	if (errores.length == 0) {
		let peticion = $.ajax({
			url: "MiServlet",
			type: "POST",
			data: {
				correoIni: correoIni,
				contraIni: contraIni
			},
			async: true,
			success: function(data) {
				if(data=="false"){
					$("#respuestainicio").html("El correo o la contraseña son incorrectos");
				}else{
					location.href ='https://www.galletagames.com';
				}			
			}, error: function(data) {
				alert("Error en la trasmision");
			}
		})
	} else {
		alert(errores);
	}
}

function verificarRegistro() {
	let correo1 = document.getElementById("correoRegistro").value;
	let contra1 = document.getElementById("contrasenaRegistro").value;
	let correo = correo1.trim();
	let contra = contra1.trim();

	let errores = [];
	if (validarcorreo(correo) == false) {
		errores.push("El correo no esta en un formato correcto \n");
	}
	if (validarcontra(contra) == false) {
		errores.push("La contraseña tiene que tener 8 caracteres, una mayuscula, una minuscula, un numero y un simbolo(!@#$%^&*) \n");
	}
	if (errores.length == 0) {
		let peticion = $.ajax({
			url: "MiServlet",
			type: "POST",
			data: {
				correo: correo,
				contra: contra
			},
			async: true,
			success: function(data) {
				if(data=="false"){
					$("#respuestaregistro").html("Ya existe una cuenta con ese correo electronico");
				}else{
					$("#respuestaregistro").html("La cuenta se ha creado correctamente");
				}
			}, error: function(data) {
				alert("Error en la trasmision");
			}
		})
	} else {
		alert(errores);
	}
}
function aleatorio() {
	let peticion = $.ajax({
		url: "MiServlet",
		type: "POST",
		data: {
			aleatorio: "hola",
		},
		async: true,
		success: function(data) {
			$("#juegoaleatorio").html(peticion.responseText);
		}, error: function(data) {
			alert("Error en la trasmision");
		}
	})
}
function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
function checkCookie() {
  let cookie = getCookie("correo");
  return cookie;
}
function header1(){
		let cabecera = "<nav class=\"navbar navbar-expand-lg bg-body-tertiary\" style='background-color: #ff9900 !important'>\r\n"
				+ "  <div class=\"container-fluid\">\r\n"
				+ "    <a class=\"navbar-brand\" href=\"MiServlet\">\r\n"
				+ "      <img src=\"../img/logo.png\" alt=\"Logo\" width=\"50\" height=\"50\" class=\"d-inline-block\">\r\n"
				+ "    </a>\r\n"
				+ "    <form class=\"d-flex justify-content-center\" role=\"search\" action=\"MiServlet\" method=\"get\">\r\n"
				+ "      <input class=\"form-control me-2\" name=\"palabra\" placeholder=\"Buscar\" aria-label=\"Search\">\r\n"
				+ "      <button class=\"botonnavbar\">Buscar</button>\r\n"
				+ "    </form>\r\n"
				+ "    <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbarSupportedContent\">\r\n"
				+ "      <ul class=\"navbar-nav\">\r\n"
				+ "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"Aleatorio.jsp\"><button class='botonnavbar'>Juego Aleatorio</button></a>\r\n"
				+ "        </li>\r\n"
				+ "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"Registro.jsp\" class='linknavbar'><button class='botonnavbar'>Inicio Sesion/Registro</button></a>\r\n"
				+ "        </li>\r\n"
				+ "      </ul>\r\n"
				+ "    </div>\r\n"
				+ "    <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "      <span class=\"navbar-toggler-icon\"></span>\r\n"
				+ "    </button>\r\n"
				+ "  </div>\r\n"
				+ "</nav>\r\n";
		return cabecera;
}
function header2(){
	let cabecera = "<nav class=\"navbar navbar-expand-lg bg-body-tertiary\" style='background-color: #ff9900 !important'>\r\n"
				+ "  <div class=\"container-fluid\">\r\n"
				+ "    <a class=\"navbar-brand\" href=\"MiServlet\">\r\n"
				+ "      <img src=\"../img/logo.png\" alt=\"Logo\" width=\"50\" height=\"50\" class=\"d-inline-block\">\r\n"
				+ "    </a>\r\n"
				+ "    <form class=\"d-flex justify-content-center\" role=\"search\" action=\"MiServlet\" method=\"get\">\r\n"
				+ "      <input class=\"form-control me-2\" name=\"palabra\" placeholder=\"Buscar\" aria-label=\"Search\">\r\n"
				+ "      <button class=\"botonnavbar\">Buscar</button>\r\n"
				+ "    </form>\r\n"
				+ "    <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbarSupportedContent\">\r\n"
				+ "      <ul class=\"navbar-nav\">\r\n"
				+ "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"Aleatorio.jsp\"><button class='botonnavbar'>Juego Aleatorio</button></a>\r\n"
				+ "        </li>\r\n"
				+ "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"MiCuenta.jsp\" class='linknavbar'><button class='botonnavbar'>Mi Cuenta</button></a>\r\n"
				+ "        </li>\r\n"
				+ "      </ul>\r\n"
				+ "    </div>\r\n"
				+ "    <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "      <span class=\"navbar-toggler-icon\"></span>\r\n"
				+ "    </button>\r\n"
				+ "  </div>\r\n"
				+ "</nav>\r\n";
		return cabecera;
}
function guardarjuego(){
	console.log("hola");
	let cookie = checkCookie();
	let idguardar = document.getElementById("botonguardar").value;
	if(cookie!=""){
		let peticion = $.ajax({
			url: "MiServlet",
			type: "POST",
			data: {
				correocookie: cookie,
				idguardar: idguardar
			},
			async: true,
			success: function(data) {
				if(data=="false"){
					alert("Ya tienes este juego guardado");
				}else{
					alert("Guardado con exito");					
				}
			}, error: function(data) {
				alert("Error en la trasmision");
			}
		})
	}else{
		alert("Debes iniciar sesión para utilizar esta función");
	}
}
function mostrarguardados(){
	let cookie = checkCookie();
	if(cookie!=""){
		let peticion = $.ajax({
			url: "MiServlet",
			type: "POST",
			data: {
				correomostrar: cookie
			},
			async: true,
			success: function(data) {
				$("#mostrarguardados").html(peticion.responseText);
			}, error: function(data) {
				alert("Error en la trasmision");
			}
		})
	}else{
		alert("Debes iniciar sesión para utilizar esta función");
	}
}
