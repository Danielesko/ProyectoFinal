package miPaquete;

public class HtmlFunciones {

	public static String cabecera() {
		
		return cabecera();
	}
}
