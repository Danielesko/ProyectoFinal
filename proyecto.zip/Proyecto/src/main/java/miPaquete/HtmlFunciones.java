package miPaquete;

import java.util.ArrayList;

public class HtmlFunciones {

	public static String header() {
		String cabecera = "";
		cabecera += "<header>\r\n" + "		<nav>\r\n" + "			<div class=\"navbar-left\">\r\n"
				+ "				<a href=\"MiServlet\"><img src=\"../img/logo.png\" alt=\"Logo\"></a>\r\n"
				+ "			</div>\r\n" + "			<div class=\"navbar-center\">\r\n"
				+ "				<form action=\"MiServlet\" method=\"get\"\r\n"
				+ "					style=\"display: flex\">\r\n"
				+ "					<input type=\"text\" placeholder=\"Buscar...\" name=\"palabra\">\r\n"
				+ "					<button class=\"botonnavbar\">Buscar</button>\r\n" + "				</form>\r\n"
				+ "			</div>\r\n" + "			<div class=\"navbar-right\">\r\n"
				+ "				<a href=\"Recomendador.jsp\"><button>Recomendador</button></a> <a\r\n"
				+ "					href=\"Aleatorio.jsp\"><button>Juego Aleatorio</button></a> <a\r\n"
				+ "					href=\"Registro.jsp\"><button>Inicio\r\n"
				+ "						Sesi&oacute;n/Registro</button></a>\r\n" + "			</div>\r\n"
				+ "		</nav>\r\n" + "	</header>";
		return cabecera;
	}
	public static String headersesion() {
		String cabecera = "";
		cabecera += "<header>\r\n" + "		<nav>\r\n" + "			<div class=\"navbar-left\">\r\n"
				+ "				<a href=\"MiServlet\"><img src=\"../img/logo.png\" alt=\"Logo\"></a>\r\n"
				+ "			</div>\r\n" + "			<div class=\"navbar-center\">\r\n"
				+ "				<form action=\"MiServlet\" method=\"get\"\r\n"
				+ "					style=\"display: flex\">\r\n"
				+ "					<input type=\"text\" placeholder=\"Buscar...\" name=\"palabra\">\r\n"
				+ "					<button class=\"botonnavbar\">Buscar</button>\r\n" + "				</form>\r\n"
				+ "			</div>\r\n" + "			<div class=\"navbar-right\">\r\n"
				+ "				<a href=\"Recomendador.jsp\"><button>Recomendador</button></a> <a\r\n"
				+ "					href=\"Aleatorio.jsp\"><button>Juego Aleatorio</button></a> <a\r\n"
				+ "					href=\"MiCuenta.jsp\">"
				+ "						¡Hola!</button></a>\r\n" + "			</div>\r\n"
				+ "		</nav>\r\n" + "	</header>";
		return cabecera;
	}

	public static String mostrarAleatorio(Juego juego) {
		String frase = "";
		String nombre = juego.getNombre();
		String foto = juego.getFoto();
		String descripcion = juego.getDescripcion();
		frase = "<div style='display:flex; justify-content:center;'>";
		frase += "<div style='width:30%;'>";
		frase += "<img src='" + foto
				+ "' alt='Foto juego aleatorio' style='width:400px;height:400px;margin-left:auto;margin-right:auto;'><br>";
		frase += "</div>";
		frase += "<div style='width:40%; text-align:justify; display:flex; flex-direction: column; align-items: center; justify-content: flex-end;'>";
		frase += "<h3>" + nombre + "</h3>";
		frase += "<p style='text-align:bottom'>" + descripcion + "</p>";
		frase += "</div>";
		frase += "</div>";

		return frase;
	}

	public static String footer() {
		String footer = "";
		footer += "		<footer>\r\n" + "				<div class=\"divfooter\">\r\n"
				+ "					<div class=\"logofooter\">\r\n"
				+ "						<img src=\"../img/logo.png\" alt=\"logo de la empresa\"\r\n"
				+ "							class=\"logofooter\">\r\n" + "					</div>\r\n"
				+ "					<div class=\"contacto\">\r\n" + "						<ul>\r\n"
				+ "							<li><h2>Compa&ntilde;ia</h2></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Sobre nosotros</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Contacto</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Sobre nosotros</a></li>\r\n"
				+ "						</ul>\r\n" + "					</div>\r\n"
				+ "					<div class=\"politicas\">\r\n" + "						<ul>\r\n"
				+ "							<li><h2>Pol&iacute;ticas</h2></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Aviso legal</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Pol&iacute;tica de\r\n"
				+ "									privacidad</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Pol&iacute;tica de\r\n"
				+ "									cookies</a></li>\r\n" + "						</ul>\r\n"
				+ "					</div>\r\n" + "					<div class=\"redes\">\r\n"
				+ "						<ul>\r\n" + "							<li><h2>Redes sociales</h2></li>\r\n"
				+ "							<li><a href=\"https://twitter.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-twitter\"></i> Twitter</a></li>\r\n"
				+ "							<li><a href=\"https://www.facebook.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-facebook\"></i> Facebook</a></li>\r\n"
				+ "							<li><a href=\"https://www.instagram.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-instagram\"></i> Instagram</a></li>\r\n"
				+ "							<li><a href=\"https://www.linkedin.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-linkedin\"></i> LinkedIn</a></li>\r\n"
				+ "						</ul>\r\n" + "					</div>\r\n" + "				</div>\r\n"
				+ "			</footer>";
		return footer;
	}

	public static String juegobuscado(ArrayList<Juego> juego) {
		String mostrar = "";
		String nombre = juego.get(0).getNombre();
		double val = juego.get(0).getValoracion();
		int fecha = juego.get(0).getFecha();
		String categoria1 = juego.get(0).getCategoria();
		String dificultad = juego.get(0).getDificultad();
		String foto = juego.get(0).getFoto();
		String descripcion = juego.get(0).getDescripcion();
		String reglas = juego.get(0).getReglas();
		String numjug = juego.get(0).getJugadores();
		String tiempo = juego.get(0).getTiempomax();
		mostrar += " <div class='game-container'>";
		mostrar += "  <h1>"+nombre+"</h1>";
		mostrar += " <img class='game-image' src='"+foto+"' alt='Imagen del juego'>";
		mostrar += " <p class='game-description'>"+descripcion+"</p>";
		mostrar += "<div class='game-details'>";
		mostrar += "   <p class='label'>Fecha:</p>";
		mostrar += "   <p>"+fecha+"</p>";
		mostrar += "    <p class='label'>Categoría:</p>";
		mostrar += "   <p>"+categoria1+"</p>";
		mostrar += "   <p class='label'>Dificultad:</p>";
		mostrar += "   <p>"+dificultad+"</p>";
		mostrar += "   <p class='label'>Número de jugadores:</p>";
		mostrar += "   <p>"+numjug+"</p>";
		mostrar += "   <p class='label'>Tiempo estimado:</p>";
		mostrar += "     <p>"+tiempo+"</p>";
		mostrar += "    </div>";
		mostrar += "    <a class='pdf-link' href='"+reglas+"' download>Descargar PDF</a>";
		mostrar += "	  </div>";
		return mostrar;
	}
}
