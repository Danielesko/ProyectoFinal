package miPaquete;

import java.util.ArrayList;

public class HtmlFunciones {

	public static String header() {
		String cabecera = "<nav class=\"navbar navbar-expand-lg bg-body-tertiary\" style='background-color: #ff9900 !important'>\r\n"
				+ "  <div class=\"container-fluid\">\r\n" + "    <a class=\"navbar-brand\" href=\"MiServlet\">\r\n"
				+ "      <img src=\"../img/logo.png\" alt=\"Logo\" width=\"50\" height=\"50\" class=\"d-inline-block\">\r\n"
				+ "    </a>\r\n"
				+ "    <form class=\"d-flex justify-content-center\" role=\"search\" action=\"MiServlet\" method=\"get\">\r\n"
				+ "      <input class=\"form-control me-2\" name=\"palabra\" placeholder=\"Buscar\" aria-label=\"Search\">\r\n"
				+ "      <button class=\"botonnavbar\">Buscar</button>\r\n" + "    </form>\r\n"
				+ "    <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbarSupportedContent\">\r\n"
				+ "      <ul class=\"navbar-nav\">\r\n" + "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"Aleatorio.jsp\"><button class='botonnavbar'>Juego Aleatorio</button></a>\r\n"
				+ "        </li>\r\n" + "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"Registro.jsp\" class='linknavbar'><button class='botonnavbar'>Inicio Sesion/Registro</button></a>\r\n"
				+ "        </li>\r\n" + "      </ul>\r\n" + "    </div>\r\n"
				+ "    <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "      <span class=\"navbar-toggler-icon\"></span>\r\n" + "    </button>\r\n" + "  </div>\r\n"
				+ "</nav>\r\n";
		return cabecera;
	}

	public static String headersesion() {
		String cabecera = "<nav class=\"navbar navbar-expand-lg bg-body-tertiary\" style='background-color: #ff9900 !important'>\r\n"
				+ "  <div class=\"container-fluid\">\r\n" + "    <a class=\"navbar-brand\" href=\"MiServlet\">\r\n"
				+ "      <img src=\"../img/logo.png\" alt=\"Logo\" width=\"50\" height=\"50\" class=\"d-inline-block\">\r\n"
				+ "    </a>\r\n"
				+ "    <form class=\"d-flex justify-content-center\" role=\"search\" action=\"MiServlet\" method=\"get\">\r\n"
				+ "      <input class=\"form-control me-2\" name=\"palabra\" placeholder=\"Buscar\" aria-label=\"Search\">\r\n"
				+ "      <button class=\"botonnavbar\">Buscar</button>\r\n" + "    </form>\r\n"
				+ "    <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbarSupportedContent\">\r\n"
				+ "      <ul class=\"navbar-nav\">\r\n" + "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"Aleatorio.jsp\"><button class='botonnavbar'>Juego Aleatorio</button></a>\r\n"
				+ "        </li>\r\n" + "        <li class=\"nav-item\">\r\n"
				+ "          <a href=\"MiServlet?ircuenta=va\" class='linknavbar'><button class='botonnavbar'>Mi Cuenta</button></a>\r\n"
				+ "        </li>\r\n" + "      </ul>\r\n" + "    </div>\r\n"
				+ "    <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "      <span class=\"navbar-toggler-icon\"></span>\r\n" + "    </button>\r\n" + "  </div>\r\n"
				+ "</nav>\r\n";
		return cabecera;
	}

	public static String mostrarAleatorio(Juego juego) {
		String frase = "";
		String nombre = juego.getNombre();
		String foto = juego.getFoto();
		String descripcion = juego.getDescripcion();
		int id = juego.getId();
		String link = "MiServlet?palabra=" + nombre;
		frase += "		<div class=\"row\">\r\n" + "		  <div class=\"col-md-6\">\r\n"
				+ "		    <div class=\"text-center\">\r\n" + "    <a href='" + link + "'>\r\n" + "      <img src='"
				+ foto + "' alt=\"Foto juego aleatorio\" class='img-fluid' style='width:400px;height:400px' > \r\n" + "    </a><br>\r\n"
				+ "		    </div>\r\n" + "		  </div>\r\n" + "		  <div class=\"col-md-6\">\r\n"
				+ "		    <div class=\"p-4\">\r\n" + "    <h3><a href='" + link + "' style='text-decoration:none;color:black'>" + nombre + "</a></h3>\r\n"
				+ "    <p class=\"text-bottom\">" + descripcion + "</p>\r\n" + "		    </div>\r\n"
				+ "    <button onclick=\"guardarjuego()\" class='botonnavbar' name='guardar' id='botonguardar' value='"+id+"'>Guardar el juego</button>\r\n" + "		    </div>\r\n"
				+ "		  </div>\r\n" + "		</div>";

		return frase;
	}

	public static String footer() {
		String footer = "<footer class=\"footer\">\r\n" + "<div class=\"container\">\r\n" + "<div class=\"row\">\r\n"
				+ "<div class=\"col-md-3\">\r\n"
				+ "<img src=\"../img/logo.png\" alt=\"Logo\" class=\"logo\" width='20%' style='margin-top:3%'>\r\n"
				+ "</div>\r\n" + "<div class=\"col-md-6\">\r\n" + "<div class=\"row\">\r\n"
				+ "<div class=\"col-md-6\">\r\n" + "<h4>Políticas</h4>\r\n" + "<ul>\r\n"
				+ "<li><a href=\"Politicas.jsp\" class='linkfooter'>Política de privacidad</a></li>\r\n"
				+ "<li><a href=\"Terminos.jsp\" class='linkfooter'>Términos y condiciones</a></li>\r\n" + "</ul>\r\n"
				+ "</div>\r\n" + "<div class=\"col-md-6\">\r\n" + "<h4>Compañía</h4>\r\n" + "<ul>\r\n"
				+ "<li><a href=\"SobreNostros.jsp\" class='linkfooter'>Acerca de nosotros</a></li>\r\n"
				+ "<li><a href=\"#\" class='linkfooter'>Nuestro equipo</a></li>\r\n"
				+ "<li><a href=\"#\" class='linkfooter'>Contáctanos</a></li>\r\n" + "</ul>\r\n" + "</div>\r\n"
				+ "</div>\r\n" + "</div>\r\n" + "<div class=\"col-md-3\">\r\n" + "<h4>Redes sociales</h4>\r\n"
				+ "<ul class=\"social-icons\">\r\n"
				+ "<li style='list-style-type:none'><a href=\"www.facebook.com\"><i class=\"fab fa-facebook\"></i></a></li>\r\n"
				+ "<li style='list-style-type:none'><a href=\"www.twitter.com\"><i class=\"fab fa-twitter\"></i></a></li>\r\n"
				+ "<li style='list-style-type:none'><a href=\"www.instagram.com\"><i class=\"fab fa-instagram\"></i></a></li>\r\n"
				+ "</ul>\r\n" + "</div>\r\n" + "</div>\r\n" + "</div>\r\n" + "</footer>";

		return footer;
	}

	public static String juegobuscado(ArrayList<Juego> juego) {
		String mostrar = "";
		String nombre = juego.get(0).getNombre();
		double val = juego.get(0).getValoracion();
		int fecha = juego.get(0).getFecha();
		String categoria1 = juego.get(0).getCategoria();
		String categoria2 = juego.get(0).getCategoria2();
		String dificultad = juego.get(0).getDificultad();
		String foto = juego.get(0).getFoto();
		String descripcion = juego.get(0).getDescripcion();
		String reglas = juego.get(0).getReglas();
		String numjug = juego.get(0).getJugadores();
		String tiempo = juego.get(0).getTiempomax();
		int id = juego.get(0).getId();
		mostrar+="<div class=\"game-container\">\r\n"
				+ "  <div class=\"row\">\r\n"
				+ "    <div class=\"col-md-6\">\r\n"
				+ "      <img class=\"game-image img-fluid\" src='" + foto + "' alt=\"Imagen del juego\">\r\n"
				+ "    </div>\r\n"
				+ "    <div class=\"col-md-6\">\r\n"
				+ "      <h1 class=\"display-4\">"+ nombre +"</h1>\r\n"
				+ "      <div class=\"game-details\">\r\n"
				+ "      <p class=\"game-description\">"+ descripcion +"</p>\r\n"
				+ "			<ul>"
				+ "        <p class=\"label\">Fecha:</p>\r\n"
				+ "        <p>" + fecha + "</p>\r\n"
				+ "        <p class=\"label\">Categoría:</p>\r\n"
				+ "        <p>" + categoria1 + "," + categoria2+ "</p><br>\r\n"
				+ "        <p class=\"label\">Dificultad:</p>\r\n"
				+ "        <p>" + dificultad + "</p><br>\r\n"
				+ "			</ul>"	
				+ "			<ul>"
				+ "        <p class=\"label\">Número de jugadores:</p>\r\n"
				+ "        <p>" + numjug + "</p><br>\r\n"
				+ "        <p class=\"label\">Tiempo estimado:</p>\r\n"
				+ "        <p>" + tiempo + "</p><br>\r\n"
				+ "        <p class=\"label\">Valoración:</p>\r\n"
				+ "        <p>" + val + "</p><br>\r\n"
				+ "			</ul>"
				+ "      </div>\r\n"
				+ "      <a class=\"pdf-link\" href='" + reglas + "' download>Descargar PDF</a><button onclick=\"guardarjuego()\" class='botonnavbar' name='guardar' id='botonguardar' value='"+id+"'>Guardar el juego</button>\r\n"
				+ "    </div>\r\n"
				+ "  </div>\r\n"
				+ "</div>\r\n";
		return mostrar;
	}
	public static String juegosguardados(ArrayList<Juego> juego) {
		String juegos = "<div class=\"container\" >\r\n"
				+ "  <div class=\"row\">\r\n";
		for(int i=0;i<juego.size();i++) {
			String foto = juego.get(i).getFoto();
			String nombre = juego.get(i).getNombre();
			String link = "MiServlet?palabra=" + nombre;
			juegos+= "<div class='col-md-4' style='margin-top:3%;margin-bottom:3%'>\r\n";
			juegos+="<div class=\"card\"><a href='" + link + "'><img src='" + foto + "' alt=\"Imagen\" class=\"card-img-top\" style='height:300px !important'></a>\r\n"
					+ "        <div class=\"card-body\">\r\n"
					+ "          <h6 class=\"card-title\">"+ nombre +"</h6>\r\n"
					+ "        </div>      </div>\r\n"
					+ "  </div>\r\n";
			}
		juegos +="    </div>\r\n"		
				+ "</div>";
		return juegos;
	}
}
