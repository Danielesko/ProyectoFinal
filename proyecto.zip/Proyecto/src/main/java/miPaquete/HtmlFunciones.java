package miPaquete;

import java.util.ArrayList;

public class HtmlFunciones {

	public static String header() {
		String cabecera="";
		cabecera+="<header>\r\n"
				+ "		<nav>\r\n"
				+ "			<div class=\"navbar-left\">\r\n"
				+ "				<a href=\"MiServlet\"><img src=\"../img/logo.png\" alt=\"Logo\"></a>\r\n"
				+ "			</div>\r\n"
				+ "			<div class=\"navbar-center\">\r\n"
				+ "				<form action=\"MiServlet\" method=\"get\"\r\n"
				+ "					style=\"display: flex\">\r\n"
				+ "					<input type=\"text\" placeholder=\"Buscar...\" name=\"palabra\">\r\n"
				+ "					<button class=\"botonnavbar\">Buscar</button>\r\n"
				+ "				</form>\r\n"
				+ "			</div>\r\n"
				+ "			<div class=\"navbar-right\">\r\n"
				+ "				<a href=\"Recomendador.jsp\"><button>Recomendador</button></a> <a\r\n"
				+ "					href=\"Aleatorio.jsp\"><button>Juego Aleatorio</button></a> <a\r\n"
				+ "					href=\"Registro.jsp\"><button>Inicio\r\n"
				+ "						Sesi&oacute;n/Registro</button></a>\r\n"
				+ "			</div>\r\n"
				+ "		</nav>\r\n"
				+ "	</header>";
		return cabecera;
	}
	public static String mostrarAleatorio(Juego juego) {
		String frase ="";
		String nombre = juego.getNombre();
		String foto = juego.getFoto();
		String descripcion = juego.getDescripcion();
		frase = "<div style='display:flex; justify-content:center;'>";
		frase += "<div style='width:30%;'>";
		frase += "<img src='" + foto + "' alt='Foto juego aleatorio' style='width:400px;height:400px;margin-left:auto;margin-right:auto;'><br>";
		frase += "</div>";
		frase += "<div style='width:40%; text-align:justify; display:flex; flex-direction: column; align-items: center; justify-content: flex-end;'>";
		frase += "<h3>" + nombre + "</h3>";
		frase += "<p style='text-align:bottom'>" + descripcion + "</p>";
		frase += "</div>";
		frase += "</div>";



		return frase;
	}
	public static String footer() {
		String footer = "";
		footer+="		<footer>\r\n"
				+ "				<div class=\"divfooter\">\r\n"
				+ "					<div class=\"logofooter\">\r\n"
				+ "						<img src=\"../img/logo.png\" alt=\"logo de la empresa\"\r\n"
				+ "							class=\"logofooter\">\r\n"
				+ "					</div>\r\n"
				+ "					<div class=\"contacto\">\r\n"
				+ "						<ul>\r\n"
				+ "							<li><h2>Compa&ntilde;ia</h2></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Sobre nosotros</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Contacto</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Sobre nosotros</a></li>\r\n"
				+ "						</ul>\r\n"
				+ "					</div>\r\n"
				+ "					<div class=\"politicas\">\r\n"
				+ "						<ul>\r\n"
				+ "							<li><h2>Pol&iacute;ticas</h2></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Aviso legal</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Pol&iacute;tica de\r\n"
				+ "									privacidad</a></li>\r\n"
				+ "							<li><a href=\"#\" class=\"linkfooter\">Pol&iacute;tica de\r\n"
				+ "									cookies</a></li>\r\n"
				+ "						</ul>\r\n"
				+ "					</div>\r\n"
				+ "					<div class=\"redes\">\r\n"
				+ "						<ul>\r\n"
				+ "							<li><h2>Redes sociales</h2></li>\r\n"
				+ "							<li><a href=\"https://twitter.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-twitter\"></i> Twitter</a></li>\r\n"
				+ "							<li><a href=\"https://www.facebook.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-facebook\"></i> Facebook</a></li>\r\n"
				+ "							<li><a href=\"https://www.instagram.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-instagram\"></i> Instagram</a></li>\r\n"
				+ "							<li><a href=\"https://www.linkedin.com\" class=\"linkfooter\"><i\r\n"
				+ "									class=\"fab fa-linkedin\"></i> LinkedIn</a></li>\r\n"
				+ "						</ul>\r\n"
				+ "					</div>\r\n"
				+ "				</div>\r\n"
				+ "			</footer>";
		return footer;
	}
	public static String juegobuscado(ArrayList<Juego> juego) {
		String mostrar ="";
		String nombre = juego.get(0).getNombre();
		String imagen = juego.get(0).getFoto();
		double val = juego.get(0).getValoracion();
		int fecha = juego.get(0).getFecha();
		String categoria1 = juego.get(0).getCategoria();
		String dificultad = juego.get(0).getDificultad();
		String foto = juego.get(0).getFoto();
		String descripcion = juego.get(0).getDescripcion();
		String reglas = juego.get(0).getReglas();
		mostrar+="<div style='display:flex;flex-direction:column;align-items:center'>";
		mostrar+="<div style='display:flex;flex-direction:column;align-items:center;margin:10px'>";
		mostrar+="<h1>"+nombre+"</h1>";
		mostrar+="</div>";
		mostrar+="<div style='display:flex;flex-wrap:wrap;justify-content:center'>";
		mostrar+="<div style='display:flex;flex-direction:column;align-items:center;margin:10px'>";
		mostrar+="<img src='"+foto+"' alt='Foto del juego de mesa' style='width: 400px; height: 400px;'>";
		mostrar+="</div>";
		mostrar+="<div style='display:flex;flex-direction:column;align-items:center;margin:10px'>";
		mostrar+="<p>"+descripcion+"</p>";
		mostrar+="<p>"+val+"</p>";
		mostrar+="<a href='"+reglas+"' download>Descargar PDF</a>";
		mostrar+="</div>";
		mostrar+="</div>";
		mostrar+="<div style='display:flex;flex-direction:column;align-items:center;margin:10px'";
		mostrar+="<h3>Categorías:</h3>";
		mostrar+="<ul>";
		mostrar+="<li>"+categoria1+"</li>";
		mostrar+="<li>Categoría 2</li>";
		mostrar+="<li>Categoría 3</li>";
	    mostrar+="</ul>";
		mostrar+="</div>";
		mostrar+="</div>";
		return mostrar;
	}
}
