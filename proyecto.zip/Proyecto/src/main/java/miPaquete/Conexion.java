package miPaquete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.jdbc.CallableStatement;

public class Conexion {
    private static Connection c = null;
    
    public static Connection conectar() throws SQLException, ClassNotFoundException {
        if (c == null) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani","Mamagracia123");
            } catch (SQLException ex) {
                throw new SQLException(ex);
            } catch (ClassNotFoundException ex) {
                throw new ClassCastException(ex.getMessage());
            }
        }
        return c;
    }

    public static void cerrar() throws SQLException {
        if (c != null) {
        	c.close();
        }
    }
}