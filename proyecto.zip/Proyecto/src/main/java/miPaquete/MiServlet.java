package miPaquete;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

/**
 * Servlet implementation class MiServlet
 */
public class MiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String registro = request.getParameter("correo");
		String inicio = request.getParameter("correoIni");
		String aleatorio = request.getParameter("aleatorio");
		String buscar = request.getParameter("palabra");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(buscar!=null) {
			ArrayList<Juego> j = AccesoDatos.mostrarJuego(buscar);
			request.setAttribute("JuegoMostrar", j);
			request.getRequestDispatcher("JuegoBuscado.jsp").forward(request, response);		
		}else if(aleatorio!=null) {
			Juego jugaleatorio = AccesoDatos.MostrarJuegoAleatorio();
			String htmlaleatorio = HtmlFunciones.mostrarAleatorio(jugaleatorio);
			out.print(htmlaleatorio);
		}else if(registro!=null) {
			String correo = request.getParameter("correo");
			String contra = request.getParameter("contra");
			boolean funciona = AccesoDatos.registro(contra, correo);
			out.print(funciona);
		}else if(inicio!=null) {
			String correo = request.getParameter("correoIni");
			String contra = request.getParameter("contraIni");
			boolean funciona = AccesoDatos.inicio(contra, correo);
			out.print(funciona);
		}else {
			ArrayList<Juego> top = AccesoDatos.jugVal();
			request.setAttribute("Top", top);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
