package miPaquete;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.catalina.connector.Response;

/**
 * Servlet implementation class MiServlet
 */
public class MiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String registro = request.getParameter("correo");
		String inicio = request.getParameter("correoIni");
		String aleatorio = request.getParameter("aleatorio");
		String buscar = request.getParameter("palabra");
		String micuenta = request.getParameter("micuenta");
		String correoguardar = request.getParameter("correocookie");
		String correomostrar = request.getParameter("correomostrar");
		String ircuenta = request.getParameter("ircuenta");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Cookie[] cookies = request.getCookies();
		if(buscar!=null) {
			ArrayList<Juego> j = AccesoDatos.mostrarJuego(buscar);
			request.setAttribute("JuegoMostrar", j);
			String tienecookie = AccesoDatos.vercookies(cookies);
			if(tienecookie!="") {
				ArrayList<String> haycookie = new ArrayList<String>();
				haycookie.add(tienecookie);
				request.setAttribute("cookieinicio", haycookie);
			}
			request.getRequestDispatcher("JuegoBuscado.jsp").forward(request, response);		
		}else if(aleatorio!=null) {
			Juego jugaleatorio = AccesoDatos.MostrarJuegoAleatorio();
			String htmlaleatorio = HtmlFunciones.mostrarAleatorio(jugaleatorio);
			out.print(htmlaleatorio);	
		}else if(registro!=null) {
			String correo = request.getParameter("correo");
			String contra = request.getParameter("contra");
			boolean funciona = AccesoDatos.registro(contra, correo);
			String tienecookie = AccesoDatos.vercookies(cookies);
			if(tienecookie!="") {
				ArrayList<String> haycookie = new ArrayList<String>();
				haycookie.add(tienecookie);
				request.setAttribute("cookieinicio", haycookie);
			}
			out.print(funciona);
		}else if(inicio!=null) {
			String correo = request.getParameter("correoIni");
			String contra = request.getParameter("contraIni");
			boolean funciona = AccesoDatos.inicio(contra, correo);
			if(funciona==true) {
				  Cookie miCookie = new Cookie ("correo", correo);
			      miCookie.setMaxAge(7200);
			      response.addCookie(miCookie);
			}
			String tienecookie = AccesoDatos.vercookies(cookies);
			if(tienecookie!="") {
				ArrayList<String> haycookie = new ArrayList<String>();
				haycookie.add(tienecookie);
				request.setAttribute("cookieinicio", haycookie);
			}
			out.print(funciona);
		}else if(micuenta != null){
			String tienecookie = AccesoDatos.vercookies(cookies);
			if(tienecookie!="") {
				ArrayList<String> haycookie = new ArrayList<String>();
				haycookie.add(tienecookie);
				request.setAttribute("cookieinicio", haycookie);
			}
			request.getRequestDispatcher("MiCuenta.jsp").forward(request, response);		
		}else if(correoguardar!=null) {
			String idguardar = request.getParameter("idguardar");
			int idjuego = Integer.parseInt(idguardar);
			boolean funciono = AccesoDatos.guardarjuego(idjuego, correoguardar);
			out.print(funciono);
		}else if(correomostrar!=null) {
			ArrayList<Juego> juegosguardados = AccesoDatos.mostrarJuegosGuardados(correomostrar);
			if(juegosguardados.size()>0) {
				String respuesta = HtmlFunciones.juegosguardados(juegosguardados);
				out.print(respuesta);
			}else {
				out.print("Aun no tienes ningun juego guardado, !busca y guardalo!");
			}
		}else if(ircuenta!=null) {
			String tienecookie = AccesoDatos.vercookies(cookies);
			if(tienecookie!="") {
				ArrayList<String> haycookie = new ArrayList<String>();
				haycookie.add(tienecookie);
				request.setAttribute("cookieinicio", haycookie);
				request.getRequestDispatcher("MiCuenta.jsp").forward(request, response);
			}
		}else {
			ArrayList<Juego> top = AccesoDatos.jugVal();
			String tienecookie = AccesoDatos.vercookies(cookies);
			if(tienecookie!="") {
				ArrayList<String> haycookie = new ArrayList<String>();
				haycookie.add(tienecookie);
				request.setAttribute("cookieinicio", haycookie);
			}
			request.setAttribute("Top", top);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
