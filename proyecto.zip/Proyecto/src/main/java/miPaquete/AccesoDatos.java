package miPaquete;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.cj.jdbc.Driver;
public class AccesoDatos {

	public static ArrayList<String> MostrarCategorias(){
		ArrayList<String> categorias = new ArrayList<String>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_","dani","Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT * From Categorias";
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				String categoria = rs.getString("nombreCat");
				categorias.add(categoria);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categorias;
		
	}
	public static ArrayList<Juego> MostrarJuegoAleatorio(int id){
		ArrayList<Juego> juego = new ArrayList<Juego>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_","dani","Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT * FROM Juegos WHERE id = '"+id+"'";
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				String nombre = rs.getString("nombre");
				int fecha = rs.getInt("fecha");
				String descripcion = rs.getString("descripcion");
				String imagen = rs.getString("imagen");
				float valoracion = rs.getFloat("valoracion");
				String num = rs.getString("num_jug");
				String tiempomax = rs.getString("tiempo_max");
				String tiempomin = rs.getString("tiempo_min");
				String reglas = rs.getNString("reglas");
				String cat = rs.getNString("categoria");
				String cat2 = rs.getNString("categoria2");
				String cat3 = rs.getNString("categoria3");
				String cat4 = rs.getNString("categoria4");
				String dificultad = rs.getString("dificultad");
				String comentario = rs.getString("comentario");
				Juego jg = new Juego(id,nombre,fecha,descripcion,imagen,valoracion,num,tiempomax,tiempomin,
						reglas,cat,cat2,cat3,cat4,dificultad,comentario);
				juego.add(jg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return juego;
		
	}
}
