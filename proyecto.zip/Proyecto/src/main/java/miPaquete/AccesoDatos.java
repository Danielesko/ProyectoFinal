package miPaquete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.catalina.connector.Response;
import org.mindrot.jbcrypt.BCrypt;
import com.mysql.cj.jdbc.Driver;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
public class AccesoDatos {
	public static void correoregistro(String to) {
		Properties props = new Properties();

		props.setProperty("mail.smtp.host", "smtp.galletagames.com");
		props.setProperty("mail.smtp.starttls.enable", "true");
		props.setProperty("mail.smtp.port","587");
		props.setProperty("mail.smtp.auth", "true");

		Session session = Session.getDefaultInstance(props);

		session.setDebug(true);
		String from = "info@galletagames.com";
		String contra = "Mamagracia123";
		MimeMessage message = new MimeMessage(session);

		try {
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject("Gracias por registrarte");
			message.setText("Gracias por registrarte en nuestra pagina web www.galletagames.com, si necesita ayuda o tiene alguna duda escribanos al correo contacto@galletagames.com");
			Transport t = session.getTransport("smtp");
			t.connect(from,contra);
			t.sendMessage(message,message.getRecipients(Message.RecipientType.TO));
			t.close();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public static ArrayList<String> MostrarCategorias() {
		ArrayList<String> categorias = new ArrayList<String>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani",
					"Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT * From Categorias";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String categoria = rs.getString("nombreCat");
				categorias.add(categoria);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categorias;

	}

	public static Juego MostrarJuegoAleatorio() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		Juego jg = new Juego();
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani",
					"Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT id AS cantidad FROM Juegos";
			ArrayList<Integer> ids = new ArrayList<>();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				int id1 = rs.getInt("cantidad");
				ids.add(id1);
			}
			int cantidad = ids.size();
			int numero = (int) (Math.random() * cantidad);
			int id = ids.get(numero);
			sql = "SELECT * FROM Juegos WHERE id = '" + id + "'";
			rs = st.executeQuery(sql);
			while (rs.next()) {
				String nombre = rs.getString("nombre");
				int fecha = rs.getInt("fecha");
				String descripcion = rs.getString("descripcion");
				String imagen = rs.getString("imagen");
				float valoracion = rs.getFloat("valoracion");
				String num = rs.getString("num_jug");
				String tiempomax = rs.getString("tiempo_max");
				String tiempomin = rs.getString("tiempo_min");
				String reglas = rs.getNString("reglas");
				String cat = rs.getNString("categoria");
				String cat2 = rs.getNString("categoria2");
				String cat3 = rs.getNString("categoria3");
				String cat4 = rs.getNString("categoria4");
				String dificultad = rs.getString("dificultad");
				String comentario = rs.getString("comentario");
				jg = new Juego(id, nombre, fecha, descripcion, imagen, valoracion, num, tiempomax, tiempomin,
						reglas, cat, cat2, cat3, cat4, dificultad, comentario);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jg;

	}
	public static ArrayList<Juego> jugVal() {
		ArrayList<Juego> juegos = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani",
					"Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT * From Juegos GROUP BY nombre ORDER BY valoracion DESC LIMIT 8";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String nombre = rs.getString("nombre");
				int fecha = rs.getInt("fecha");
				String descripcion = rs.getString("descripcion");
				String imagen = rs.getString("imagen");
				float valoracion = rs.getFloat("valoracion");
				String num = rs.getString("num_jug");
				String tiempomax = rs.getString("tiempo_max");
				String tiempomin = rs.getString("tiempo_min");
				String reglas = rs.getNString("reglas");
				String cat = rs.getNString("categoria");
				String cat2 = rs.getNString("categoria2");
				String cat3 = rs.getNString("categoria3");
				String cat4 = rs.getNString("categoria4");
				String dificultad = rs.getString("dificultad");
				String comentario = rs.getString("comentario");
				Juego jg = new Juego(nombre, fecha, descripcion, imagen, valoracion, num, tiempomax, tiempomin, reglas,
						cat, cat2, cat3, cat4, dificultad, comentario);
				juegos.add(jg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return juegos;
	}

	public static boolean registro(String contra, String correo) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		boolean verdadero = false;
		boolean comprueba =false;
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani",
					"Mamagracia123");
			Statement st = c.createStatement();
			String hashedPassword = BCrypt.hashpw(contra, BCrypt.gensalt());
			String sql = "SELECT * FROM Usuarios WHERE correo = '"+correo+"'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String correoprueba = rs.getString("correo");
				if(correoprueba!="") {
					comprueba = true;
				}
			}
			if(comprueba==false) {
				String sql1 = "INSERT INTO Usuarios VALUES(null,'"+correo+"','"+hashedPassword+"')";
				st.executeUpdate(sql1);
				verdadero = true;
				correoregistro(correo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return verdadero;
	}
	public static boolean inicio(String contra, String correo) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		boolean verdadero = false;
		String contrabbdd ="";
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani",
					"Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT * From Usuarios WHERE correo = '"+correo+"'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				contrabbdd = rs.getString("contrasena");
			}
			if(contrabbdd!=null) {
				if (BCrypt.checkpw(contra,contrabbdd)==true) {
					verdadero= true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//BCrypt.checkpw(userInputPassword, hashedPassword);
		return verdadero;
	}
	public static ArrayList<Juego> mostrarJuego(String nombre1) {
		ArrayList<Juego> juegos = new ArrayList<>();
		Juego j = new Juego();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Connection c = DriverManager.getConnection("jdbc:mysql://mysql.galletagames.com:3306/galletagms_", "dani",
					"Mamagracia123");
			Statement st = c.createStatement();
			String sql = "SELECT * From Juegos WHERE nombre = '"+nombre1+"'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String nombre = rs.getString("nombre");
				int fecha = rs.getInt("fecha");
				String descripcion = rs.getString("descripcion");
				String imagen = rs.getString("imagen");
				float valoracion = rs.getFloat("valoracion");
				String num = rs.getString("num_jug");
				String tiempomax = rs.getString("tiempo_max");
				String tiempomin = rs.getString("tiempo_min");
				String reglas = rs.getNString("reglas");
				String cat = rs.getNString("categoria");
				String cat2 = rs.getNString("categoria2");
				String cat3 = rs.getNString("categoria3");
				String cat4 = rs.getNString("categoria4");
				String dificultad = rs.getString("dificultad");
				String comentario = rs.getString("comentario");
				j = new Juego(nombre, fecha, descripcion, imagen, valoracion, num, tiempomax, tiempomin, reglas,
						cat, cat2, cat3, cat4, dificultad, comentario);
				juegos.add(j);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return juegos;
	}
}
