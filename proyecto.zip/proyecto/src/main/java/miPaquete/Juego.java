package miPaquete;

public class Juego {

	private int id;
	private String nombre;
	private int fecha;
	private String descripcion;
	private String foto;
	private double valoracion;
	private String jugadores;
	private String tiempomax;
	private String tiempomin;
	private String reglas;
	private String categoria;
	private String categoria2;
	private String categoria3;
	private String categoria4;
	private String dificultad;
	private String comentario;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getFecha() {
		return fecha;
	}
	public void setFecha(int fecha) {
		this.fecha = fecha;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	public double getValoracion() {
		return valoracion;
	}
	public void setValoracion(double valoracion) {
		this.valoracion = valoracion;
	}
	public String getJugadores() {
		return jugadores;
	}
	public void setJugadores(String jugadores) {
		this.jugadores = jugadores;
	}
	public String getTiempomax() {
		return tiempomax;
	}
	public void setTiempomax(String tiempomax) {
		this.tiempomax = tiempomax;
	}
	public String getTiempomin() {
		return tiempomin;
	}
	public void setTiempomin(String tiempomin) {
		this.tiempomin = tiempomin;
	}
	public String getReglas() {
		return reglas;
	}
	public void setReglas(String reglas) {
		this.reglas = reglas;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getCategoria2() {
		return categoria2;
	}
	public void setCategoria2(String categoria2) {
		this.categoria2 = categoria2;
	}
	public String getCategoria3() {
		return categoria3;
	}
	public void setCategoria3(String categoria3) {
		this.categoria3 = categoria3;
	}
	public String getCategoria4() {
		return categoria4;
	}
	public void setCategoria4(String categoria4) {
		this.categoria4 = categoria4;
	}
	public String getDificultad() {
		return dificultad;
	}
	public void setDificultad(String dificultad) {
		this.dificultad = dificultad;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public Juego(int id, String nombre, int fecha, String descripcion, String foto, double valoracion, String jugadores,
			String tiempomax, String tiempomin, String reglas, String categoria, String categoria2, String categoria3,
			String categoria4, String dificultad, String comentario) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.fecha = fecha;
		this.descripcion = descripcion;
		this.foto = foto;
		this.valoracion = valoracion;
		this.jugadores = jugadores;
		this.tiempomax = tiempomax;
		this.tiempomin = tiempomin;
		this.reglas = reglas;
		this.categoria = categoria;
		this.categoria2 = categoria2;
		this.categoria3 = categoria3;
		this.categoria4 = categoria4;
		this.dificultad = dificultad;
		this.comentario = comentario;
	}
	@Override
	public String toString() {
		return "Juego [id=" + id + ", nombre=" + nombre + ", fecha=" + fecha + ", descripcion=" + descripcion
				+ ", foto=" + foto + ", valoracion=" + valoracion + ", jugadores=" + jugadores + ", tiempomax="
				+ tiempomax + ", tiempomin=" + tiempomin + ", reglas=" + reglas + ", categoria=" + categoria
				+ ", categoria2=" + categoria2 + ", categoria3=" + categoria3 + ", categoria4=" + categoria4
				+ ", dificultad=" + dificultad + ", comentario=" + comentario + "]";
	}
	public Juego() {
		super();
	}

	
	
	
}
