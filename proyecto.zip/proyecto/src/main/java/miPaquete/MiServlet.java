package miPaquete;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 * Servlet implementation class MiServlet
 */
public class MiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String accion = request.getParameter("accion");
		if(accion!=null) {
			if(accion.equals("MostrarAleatorio")) {
				ArrayList<Juego> jugaleatorio = AccesoDatos.MostrarJuegoAleatorio();
				request.setAttribute("Juego", jugaleatorio);
				request.getRequestDispatcher("Aleatorio.jsp").forward(request, response);
			}
			if(accion.equals("insertar")){
				String nombre = request.getAtributte("nombre");
				int fecha = request.getAtributte("fecha");
				String descripcion = request.getAtributte("descripcion");
				String img = request.getAtributte("img");
				String numjug = request.getAtributte("numjug");
				String tiempomax = request.getAtributte("tiempomax");
				String tiempomin = request.getAtributte("tiempomin");
				String reglas = request.getAtributte("reglas");
				String categoria = request.getAtributte("categoria");
				String categoria2 = request.getAtributte("categoria2");
				String categoria3 = request.getAtributte("categoria3");
				String categoria4 = request.getAtributte("categoria4");
				String dificultad = request.getAtributte("dificultad");
				Juego j = new Juego(null,nombre,fecha,descripcion,img,null,numjug,tiempomax,tiempomin
				,reglas,categoria,categoria2,categoria3,categoria4,dificultad,null);
				AccesoDatos.add(j);
			}
		}

		//request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
